package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class flightavailability_SD {
	
	WebDriver driver = null;
	
	@Given("user is on the website")
	public void user_is_on_the_website() throws InterruptedException {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/webdrivers/chromedriver.exe");
		ChromeOptions CO= new ChromeOptions();
		
		CO.addArguments("--remote-allow-origins=*", "ignore-certificate-errors");
		CO.addArguments("start-maximized");
		
		driver= new ChromeDriver(CO);
		
		driver.get("https://blazedemo.com/");
		
		Thread.sleep(3000);
		
	}

	@When("user selects Boston as Departure city")
	public void user_selects_boston_as_departure_city() throws InterruptedException {
			
		WebElement element1=driver.findElement(By.xpath("//select[@name='fromPort']"));
		Select S1= new Select(element1);
		S1.selectByValue("Boston");
		Thread.sleep(3000);
	}

	@And("user selects New York as Destination city")
	public void user_selects_new_york_as_destination_city() throws InterruptedException {
		WebElement element2=driver.findElement(By.xpath("//select[@name='toPort']"));
		Select S2= new Select(element2);
		S2.selectByValue("New York");
		Thread.sleep(3000);
		
	}

	@Then("clicks on Find Flight Button")
	public void clicks_on_find_flight_button() throws InterruptedException {
		driver.findElement(By.xpath("//*[starts-with(@type,'submit')]")).click();
		Thread.sleep(2000);
		driver.close();
	}

}
